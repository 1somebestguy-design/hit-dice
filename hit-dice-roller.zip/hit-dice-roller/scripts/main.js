/**
 * Hit Dice Roller — Foundry VTT Module
 * Creates a macro on first load that can be dragged to the hotbar.
 * Clicking the macro opens a dialog to roll d8 or d12 hit dice
 * for the currently selected (or owned) character.
 */

const MODULE_ID  = "hit-dice-roller";
const MACRO_NAME = "Roll Hit Die";
const MACRO_IMG  = "icons/svg/d20-grey.svg";

// ─── On ready: create the macro if it doesn't exist yet ─────────────────────

Hooks.once("ready", async () => {
  // Only create for GMs and players who own characters
  if (!game.user) return;

  const existing = game.macros.find(m => m.name === MACRO_NAME && m.getFlag(MODULE_ID, "auto"));
  if (existing) return;

  await Macro.create({
    name: MACRO_NAME,
    type: "script",
    img: MACRO_IMG,
    command: `game.modules.get("${MODULE_ID}").api.openDialog()`,
    flags: { [MODULE_ID]: { auto: true } }
  });

  ui.notifications.info('Hit Dice Roller: макрос "Roll Hit Die" создан — перетащи его на панель быстрого доступа!');
});

// ─── Expose public API so the macro can call it ──────────────────────────────

Hooks.once("init", () => {
  game.modules.get(MODULE_ID).api = {
    openDialog: openHitDiceDialog
  };
});

// ─── Helpers ─────────────────────────────────────────────────────────────────

/** Get the actor to roll for: selected token → owned character → null */
function getActor() {
  // Prioritise the controlled token on the canvas
  const controlled = canvas?.tokens?.controlled ?? [];
  if (controlled.length === 1) {
    const a = controlled[0].actor;
    if (a && a.type === "character") return a;
  }

  // Fall back to the player's assigned character
  const assigned = game.user.character;
  if (assigned && assigned.type === "character") return assigned;

  return null;
}

// ─── Dialog ──────────────────────────────────────────────────────────────────

async function openHitDiceDialog() {
  const actor = getActor();

  if (!actor) {
    ui.notifications.warn("Выбери токен персонажа на карте или привяжи персонажа к своему аккаунту.");
    return;
  }

  const d8Available  = countAvailableHitDice(actor, "d8");
  const d12Available = countAvailableHitDice(actor, "d12");

  if (d8Available === 0 && d12Available === 0) {
    ui.notifications.warn(`У ${actor.name} не осталось костей здоровья!`);
    return;
  }

  const content = buildDialogContent(actor, d8Available, d12Available);

  new Dialog({
    title: `Кость здоровья — ${actor.name}`,
    content,
    buttons: {
      d8: {
        icon: '<i class="fas fa-dice-d8"></i>',
        label: `Бросить d8 (осталось: ${d8Available})`,
        callback: () => rollHitDie(actor, "d8")
      },
      d12: {
        icon: '<i class="fas fa-dice-d12"></i>',
        label: `Бросить d12 (осталось: ${d12Available})`,
        callback: () => rollHitDie(actor, "d12")
      },
      cancel: {
        icon: '<i class="fas fa-times"></i>',
        label: "Отмена"
      }
    },
    default: d8Available > 0 ? "d8" : "d12",
    render: (html) => {
      if (d8Available  === 0) html.find('[data-button="d8"]').prop("disabled", true).addClass("disabled");
      if (d12Available === 0) html.find('[data-button="d12"]').prop("disabled", true).addClass("disabled");
    }
  }, {
    classes: ["dialog", "hdr-dialog"],
    width: 420
  }).render(true);
}

function buildDialogContent(actor, d8Available, d12Available) {
  const con     = actor.system.abilities?.con?.mod ?? 0;
  const conSign = con >= 0 ? `+${con}` : `${con}`;
  const hp      = actor.system.attributes?.hp;

  return `
    <div class="hdr-dialog-body">
      <div class="hdr-actor-name">${actor.name}</div>
      <div class="hdr-hp-info">
        <span class="hdr-label">Текущее HP:</span>
        <span class="hdr-value">${hp?.value ?? "?"} / ${hp?.max ?? "?"}</span>
      </div>
      <div class="hdr-con-info">
        <span class="hdr-label">Модификатор Телосложения:</span>
        <span class="hdr-value">${conSign}</span>
      </div>
      <hr/>
      <div class="hdr-dice-grid">
        <div class="hdr-die-card ${d8Available === 0 ? "hdr-die-empty" : ""}">
          <div class="hdr-die-icon">d8</div>
          <div class="hdr-die-count">${d8Available} шт.</div>
          <div class="hdr-die-formula">1d8 ${conSign}</div>
        </div>
        <div class="hdr-die-card ${d12Available === 0 ? "hdr-die-empty" : ""}">
          <div class="hdr-die-icon">d12</div>
          <div class="hdr-die-count">${d12Available} шт.</div>
          <div class="hdr-die-formula">1d12 ${conSign}</div>
        </div>
      </div>
      <p class="hdr-hint">Выберите кость для броска. HP будут восстановлены автоматически.</p>
    </div>
  `;
}

// ─── Core logic ───────────────────────────────────────────────────────────────

function countAvailableHitDice(actor, denomination) {
  let available = 0;
  for (const item of actor.items) {
    if (item.type !== "class") continue;
    const hd = item.system?.hitDice ?? "";
    if (hd.toLowerCase() !== denomination.toLowerCase()) continue;
    const total = item.system?.levels ?? 0;
    const used  = item.system?.hitDiceUsed ?? 0;
    available  += Math.max(0, total - used);
  }
  return available;
}

async function rollHitDie(actor, denomination) {
  const classItem = actor.items.find(i => {
    if (i.type !== "class") return false;
    const hd   = i.system?.hitDice ?? "";
    const used = i.system?.hitDiceUsed ?? 0;
    const lvl  = i.system?.levels ?? 0;
    return hd.toLowerCase() === denomination.toLowerCase() && used < lvl;
  });

  if (!classItem) {
    ui.notifications.warn(`Нет доступных костей ${denomination}!`);
    return;
  }

  const conMod   = actor.system.abilities?.con?.mod ?? 0;
  const formula  = `1${denomination} + ${conMod}`;
  const roll     = new Roll(formula, actor.getRollData());
  await roll.evaluate();

  const recovered = Math.max(1, roll.total);
  const hp        = actor.system.attributes.hp;
  const newHp     = Math.min(hp.max, (hp.value ?? 0) + recovered);

  await classItem.update({
    "system.hitDiceUsed": (classItem.system.hitDiceUsed ?? 0) + 1
  });

  await actor.update({ "system.attributes.hp.value": newHp });

  await roll.toMessage({
    speaker: ChatMessage.getSpeaker({ actor }),
    flavor: `
      <div class="hdr-chat-header">
        <strong>${actor.name}</strong> бросает кость здоровья <em>${denomination}</em>
      </div>
      <div class="hdr-chat-result">
        Восстановлено HP: <strong>+${recovered}</strong>
        (${hp.value} → ${newHp} / ${hp.max})
      </div>
    `,
    rollMode: game.settings.get("core", "rollMode")
  });

  ui.notifications.info(`${actor.name} восстанавливает ${recovered} HP!`);
}
